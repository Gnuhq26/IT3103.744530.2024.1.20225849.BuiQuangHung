
// Example 4: ShowTwoNumber.java
import javax.swing.JOptionPane;

public class ShowTwoNumber {
    public static void main(String[] args) {
        String strNum1, strNum2;
        String strNotification = "You're just entered: ";
        strNum1 = JOptionPane.showInputDialog(null,
                "Please input the first number: ",
                "Bui Quang Hung 20225849 - Input the first number", JOptionPane.INFORMATION_MESSAGE);
        strNotification += strNum1 + " and ";
        strNum2 = JOptionPane.showInputDialog(null,
         "Please input the second number: ",
          "Bui Quang Hung - Input the second number",
                JOptionPane.INFORMATION_MESSAGE);
        strNotification += strNum2;
        JOptionPane.showMessageDialog(null, strNotification,
         "Show two number", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
}